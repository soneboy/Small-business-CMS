

<div class="dash_box" style="float:left">
    <div class="dash_header">
      <i class="fa fa-home"></i>
      <a href="panel.php?id=homepage">Homepage</a>
    </div><!--#dash_header-->
    <div class="dash_main">
      <p>Edit slider photos,columns,text and images,create and edit gallery on homepage.
   </p> 
    </div><!--#dash_main-->
     <div class="box_footer">
   <a href="panel.php?id=homepage">Edit</a>
   </div><!--#box_footer-->
  </div><!--#dash_box-->

   <div class="dash_box" style="float:right;">
    <div class="dash_header">
    <i class="fa fa-file"></i>
      <a href="panel.php?id=pages">Pages</a>
    </div><!--#dash_header-->
    <div class="dash_main">
    <p>Make additional pages and add content.
   </p> 

    </div><!--#dash_main-->
     <div class="box_footer">
   <a href="panel.php?id=pages">Edit</a>
   </div><!--#box_footer-->
  </div><!--#dash_box-->

   <div class="dash_box" style="float:left;">
    <div class="dash_header">
    <i class="fa fa-file-text-o"></i>
      <a href="panel.php?id=homepage">Posts</a>
    </div><!--#dash_header-->
    <div class="dash_main">
      <p>Create,edit and delete posts,manage user comments on blog page.
   </p> 
    </div><!--#dash_main-->
     <div class="box_footer">
   <a href="panel.php?id=posts">Edit</a>
   </div><!--#box_footer-->
  </div><!--#dash_box-->

   <div class="dash_box" style="float:right;">
    <div class="dash_header">
    <i class="fa fa-cogs"></i>
      <a href="panel.php?id=settings">Settings</a>
    </div><!--#dash_header-->
    <div class="dash_main">
      <p>Change logo and background color,upload font awesome icons,create social media links.
   </p> 
    </div><!--#dash_main-->
     <div class="box_footer">
   <a href="panel.php?id=settings">Edit</a>

   </div><!--#box_footer-->
  </div><!--#dash_box-->
  <script>
$(".dash_main").mouseover(function(){
  $(this).css("opacity","1");

});
$(".dash_main").mouseleave(function(){
  $(this).css("opacity","0.5");
});

</script>
