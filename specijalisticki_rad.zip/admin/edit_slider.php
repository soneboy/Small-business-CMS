

<div id="edit_slider_heading">
<h2>Edit slider</h2>
</div><!--#edit_slider_heading-->
<div id="edit_slider">
 <div id="edit_slider_header">
 <h2>Change slider photos</h2>
 </div><!--#edit_slider_header-->
<?php

$slider_photos=new Photos();
$slider_photos->display_slider_for_admin();
 


?>
</div><!--#edit_slider-->


