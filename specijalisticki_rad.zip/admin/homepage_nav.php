 <div id="homepage_nav">
   <table>
    <tr>

    <td><a style="background:#DC143C;"  href="panel.php?id=homepage&page_id=1">Edit gallery</a></td>
    <td><a href="panel.php?id=homepage&page_id=2">Edit slider</a></td>
  </tr>
  <tr>
    
    <td><a style="background:black;" href="panel.php?id=homepage&page_id=3">Edit coloumn 1</a></td>
    <td><a style="background:#008000;" href="panel.php?id=homepage&page_id=4">Edit coloumn 2</a></td>
  </tr>
   </table>
  
    </div><!--#homepage_nav-->
