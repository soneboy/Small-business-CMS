<div id="posts">
<i class="fa fa-file-text-o" style="color:black;opacity:0.5;font-size:300%;margin-bottom:20px;"> Posts</i><br/>
<img src="../img/Coming-Soon.gif" />


</div><!--#posts