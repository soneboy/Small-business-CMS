<div id="settings">
<i class="fa fa-code" style="color:black;opacity:0.5;font-size:300%;margin-bottom:20px;"> Settings</i><br/>
<img src="../img/Coming-Soon.gif" />


</div><!--#settings