
<ul style="float:left;font-family:Arial, Helvetica, sans-serif;font-size:90%;">
 <li><strong>PHP </strong>(Object Oriented and procedural)</li>
 <li><strong>MySQL/SQL</strong></li>
 <li><strong>HTML</strong></li>
 <li><strong>CSS</strong></li>
 <li><strong>jQuery</strong></li>
 <li><strong>Wordpress</strong></li>

</ul>
<ul style="float: right;margin-right:1000px;font-family:Arial, Helvetica, sans-serif;font-size:90%;">
 <li><strong>LAMP/XAMPP</strong></li>
 <li><strong>Phpmyadmin</strong></li>
 <li><strong>Sublime Text/Dreamweaver/Notepad++</strong></li>
 <li><strong>Linux mint</strong></li>
</ul>

