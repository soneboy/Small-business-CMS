<div id="blog_page">
 <div id="blogs_wrapper">
   <?php
$blog=new Posts();
$post_id=isset($_GET['post_id'])?$_GET['post_id']:null;
if($post_id){
$blog->full_post($post_id);
}
else{

$blog->test();
}?>
</div><!--#blogs_wrapper-->
<div id="list_blogs">
<h2>Najnoviji blogovi</h2>

<ul>
<?php $blog->list_all_posts();?>
</ul>





</div><!--#list_blogs-->

</div><!--#blog_page -->