

<?php

class Database{

static $connect;
static $result;

public function __construct(){
    
    try{
	self::$connect=new PDO('mysql:host=localhost;dbname=specijalisticki_rad','root','');
       }
	catch(Eception $e){
		$error=$e->showMessage();
	}
	if(isset($error)){
		echo $error;
	}
	
}

public function login($username,$password){

	$sql="SELECT * FROM users ";
	$sql.="WHERE username='{$username}' AND password='{$password}' ";
	


	$row=self::$connect->query($sql)->rowCount();
	if($row>=1){
		$_SESSION['admin']=$username;
		header('Location: panel.php?id=dashboard');
      }

	


	
}


}










?>