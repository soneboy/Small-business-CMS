<div id="footer">
<div id="social">
<i class="fa fa-facebook-square"></i>
<i class="fa fa-twitter-square"></i>
<i class="fa fa-linkedin-square"></i>
</div>
</div>