<?php require_once("initialize.php");?>
<!DOCTYPE html>
<html>
<head>
	<title>Specijalisticki rad</title>

<link rel="stylesheet" type="text/css" href="css.css">
<link rel="stylesheet" href="nivo-slider/nivo-slider.css" type="text/css" />
<link rel="stylesheet" href="nivo-slider/themes/default/default.css" type="text/css" />
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<script type="text/javascript" src="jquery-2.0.3.min.js"></script>
<script src="jquery.nivo.slider.pack.js" type="text/javascript"></script>

<script type="text/javascript">
$(window).load(function() {
    $('#slider').nivoSlider();
});
</script>

</head>
<body>
<div id="wrapper">
<div id="header">
<div id="logo">
<img src="img/logo.png" />
</div><!--end of logo-->
<div id="navigation">
<?php
$navigation=new Pages();
$navigation->navigation();?>
</div><!--end of navigation -->
</div><!--End of header-->
<?php
$page=isset($_GET['page_id'])?$_GET['page_id']:1;

if($page==1){
	include("homepage.php");
}
else{
	include("pages.php");
}
include('footer.php');


?>

</div><!--End of wrapper !-->
</body>
</html>


