<?php require_once("classes/database.php");?>
<?php require_once("classes/pages.php");?>
<?php require_once("classes/posts.php");?>
<?php require_once("classes/photos.php");?>
<?php require_once("config.php");?>